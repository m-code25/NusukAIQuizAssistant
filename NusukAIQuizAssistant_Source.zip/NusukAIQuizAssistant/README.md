# Nusuk AI Quiz Assistant

Android starter project. It selects a quiz screenshot and asks Gemini to read the question, suggest an answer, and explain it in Bengali.

## Import/build
1. Extract this ZIP.
2. Open the extracted folder in Android Studio.
3. Allow Gradle sync. If Android Studio asks for an SDK, install Android SDK 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Use
- Run the app.
- Enter your own Gemini API key in the app (it stays in memory only while the app is open).
- Select a screenshot and tap "প্রশ্ন বিশ্লেষণ".

## Important
- This is a starter source project, not a prebuilt APK.
- The app only analyzes a screenshot. It does not click, choose, or submit answers in Nusuk.
- Never publish an API key in GitHub or share it in chat. A public/distributed app should use a secure backend rather than embedding a private API key.
- Check current Gemini API availability, model names, quotas, and applicable age/region terms before use. Ask a parent/guardian or trusted adult to help with API account setup if needed.
