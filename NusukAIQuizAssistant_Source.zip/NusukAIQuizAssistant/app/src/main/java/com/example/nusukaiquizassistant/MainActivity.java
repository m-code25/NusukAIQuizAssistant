package com.example.nusukaiquizassistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 10;
    private EditText apiKey;
    private TextView result;
    private Uri selectedImage;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 28, 28, 28);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);

        TextView heading = new TextView(this);
        heading.setText("Nusuk AI Quiz Assistant");
        heading.setTextSize(24);
        layout.addView(heading);

        TextView note = new TextView(this);
        note.setText("কুইজের স্ক্রিনশট নির্বাচন করুন। AI উত্তর ও ব্যাখ্যা প্রস্তাব করবে; Nusuk-এ উত্তর নিজে যাচাই করে নির্বাচন করুন।");
        note.setTextSize(16);
        layout.addView(note);

        apiKey = new EditText(this);
        apiKey.setHint("Gemini API key (এই ডিভাইসে অস্থায়ীভাবে)");
        apiKey.setSingleLine(true);
        layout.addView(apiKey);

        Button pick = new Button(this);
        pick.setText("স্ক্রিনশট নির্বাচন");
        layout.addView(pick);
        pick.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(Intent.createChooser(intent, "ছবি নির্বাচন"), PICK_IMAGE);
        });

        Button analyze = new Button(this);
        analyze.setText("প্রশ্ন বিশ্লেষণ");
        layout.addView(analyze);
        result = new TextView(this);
        result.setTextSize(16);
        result.setPadding(0, 20, 0, 0);
        layout.addView(result);
        analyze.setOnClickListener(v -> analyzeImage());

        setContentView(scroll);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            result.setText("ছবি নির্বাচন করা হয়েছে। এখন ‘প্রশ্ন বিশ্লেষণ’ চাপুন।");
        }
    }

    private void analyzeImage() {
        String key = apiKey.getText().toString().trim();
        if (key.isEmpty()) { apiKey.setError("Gemini API key দিন"); return; }
        if (selectedImage == null) { result.setText("আগে একটি স্ক্রিনশট নির্বাচন করুন।"); return; }
        result.setText("বিশ্লেষণ হচ্ছে…");
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(selectedImage);
                Bitmap bitmap = BitmapFactory.decodeStream(in);
                in.close();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, bytes);
                String encoded = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);

                JSONObject partText = new JSONObject();
                partText.put("text", "Read this quiz screenshot. Identify the question and choices. Suggest the most likely correct answer and explain briefly in Bengali. If unclear, say so. Do not interact with or submit anything in another app.");
                JSONObject partImage = new JSONObject();
                JSONObject inline = new JSONObject();
                inline.put("mimeType", "image/jpeg");
                inline.put("data", encoded);
                partImage.put("inlineData", inline);
                JSONArray parts = new JSONArray().put(partText).put(partImage);
                JSONObject content = new JSONObject().put("parts", parts);
                JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));

                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + key);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                OutputStream out = conn.getOutputStream();
                out.write(body.toString().getBytes("UTF-8"));
                out.close();
                InputStream response = (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300)
                        ? conn.getInputStream() : conn.getErrorStream();
                ByteArrayOutputStream responseBytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int n;
                while ((n = response.read(buffer)) != -1) responseBytes.write(buffer, 0, n);
                response.close();
                String raw = responseBytes.toString("UTF-8");
                if (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) {
                    JSONObject json = new JSONObject(raw);
                    String answer = json.getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                    runOnUiThread(() -> result.setText(answer));
                } else {
                    runOnUiThread(() -> result.setText("API ত্রুটি: " + raw));
                }
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> result.setText("সমস্যা হয়েছে: " + e.getMessage()));
            }
        }).start();
    }
}
